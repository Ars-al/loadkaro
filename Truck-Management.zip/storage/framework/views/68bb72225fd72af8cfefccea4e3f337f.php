<?php $__env->startSection('section'); ?>
<div class="page-wrapper">
    <div class="content container-fluid">
        <div class="page-header">
            <div class="d-flex align-items-center">
                <div class="col">
                    <h3 class="page-title">Edit Plan</h3>
                    <ul class="breadcrumb">
                        <li class="breadcrumb-item">
                            <a href="<?php echo e(route('index')); ?>">Dashboard</a>
                        </li>
                        <li class="breadcrumb-item active">Edit Plan</li>
                    </ul>
                </div>
            </div>
        </div>

        <div class="card">
            <div class="card-body">
                <form action="<?php echo e(route('plans.update', $plan->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>

                    <div class="form-group">
                        <label for="name">Plan Name</label>
                        <input type="text" name="name" id="name" class="form-control" value="<?php echo e(old('name', $plan->name)); ?>" required>
                    </div>

                    <div class="form-group">
                        <label for="price">Price (INR)</label>
                        <input type="number" name="price" id="price" class="form-control" value="<?php echo e(old('price', $plan->price)); ?>" required>
                    </div>

                    <div class="form-group">
                        <label for="leads_limit">Leads Limit</label>
                        <input type="number" name="leads_limit" id="leads_limit" class="form-control" value="<?php echo e(old('leads_limit', $plan->leads_limit)); ?>" required>
                    </div>

                    <div class="form-group">
                        <label for="features">Features (Comma Separated)</label>
                        <textarea name="features" id="features" class="form-control" rows="3" style="height: 100px;" required><?php echo e(old('features', $plan->features)); ?></textarea>
                    </div>

                    <button type="submit" class="btn btn-primary">Update Plan</button>
                    <a href="<?php echo e(route('plans.index')); ?>" class="btn btn-secondary">Cancel</a>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\FixTech Solution\Truck-Management\resources\views\admin\plans\edit.blade.php ENDPATH**/ ?>