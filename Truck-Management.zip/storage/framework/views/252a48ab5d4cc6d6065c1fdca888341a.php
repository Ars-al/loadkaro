<?php $__env->startSection('section'); ?>
    <section class="content">
        <div class="page-wrapper">
            <div class="content container-fluid">

                <div class="page-header">
                    <div class="row">
                        <div class="col">
                            <h3 class="page-title"><?php echo e($title ?? ''); ?></h3>
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item">
                                    <a href="<?php echo e(route('transporter.index')); ?>">
                                        Dashboard
                                    </a>
                                </li>
                                <li class="breadcrumb-item active"><?php echo e($title ?? ''); ?></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <!-- /Page Header -->

                <!-- Main content -->
                <section class="content">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-12">
                                <div class="card">
                                    
                                    <div class="card-body">
                                        <form action="" method="post">
                                            <?php echo csrf_field(); ?>
                                            <div class="table-responsive">
                                                <table class="datatable table table-hover table-center mb-0">
                                                    <thead>
                                                        <tr>
                                                            <th>#</th>
                                                            
                                                            <th>Truck Type</th>
                                                            <th>Weight</th>
                                                            
                                                            <th>Origin</th>
                                                            <th>Destination</th>
                                                            <th>Schedule Date</th>
                                                            <th>My Bid</th>
                                                            <th>Date</th>
                                                            <th>Action</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php $__currentLoopData = $mybids; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <tr>
                                                                <td><?php echo e($loop->iteration); ?></td>
                                                                <td><?php echo e(ucfirst($item->requestTruck->type ?? '')); ?></td>
                                                                <td><?php echo e($item->requestTruck->weight ?? ''); ?></td>
                                                                
                                                                <td><?php echo e($item->requestTruck->origin ?? ''); ?></td>
                                                                <td><?php echo e($item->requestTruck->destination ?? ''); ?></td>
                                                                
                                                                <td>
                                                                    <?php if($item->schedule_date): ?>
                                                                        <?php echo e(\Carbon\Carbon::parse($item->schedule_date)->format('d M Y')); ?>

                                                                    <?php else: ?>
                                                                        <span class="badge badge-primary">Check Info</span>
                                                                    <?php endif; ?>
                                                                </td>
                                                                <td>
                                                                    ₹<?php echo e(number_format($item->bid, 2) ?? ''); ?>

                                                                </td>
                                                                <td><?php echo e($item->created_at->format('d M Y') ?? ''); ?></td>
                                                                <td>
                                                                    <?php if($item->id == $item->requestTruck->winning_bid_id): ?>
                                                                        <a href="<?php echo e(route('transporter.mybid.detail', ['id' => $item->id])); ?>"
                                                                            class="btn btn-dark btn-sm">
                                                                            <i class="fa-regular fa-eye"></i>
                                                                            Detail
                                                                        </a>
                                                                    <?php endif; ?>
                                                                    <button class="btn btn-primary btn-sm" type="button"
                                                                        data-bs-toggle="modal"
                                                                        data-bs-target="#info<?php echo e($loop->iteration); ?>">
                                                                        <i class="fa-regular fa-eye"></i>
                                                                        Info
                                                                    </button>
                                                                    <button class="btn btn-danger btn-sm" type="button"
                                                                        data-bs-toggle="modal"
                                                                        data-bs-target="#delete<?php echo e($loop->iteration); ?>">
                                                                        <i class="fa-regular fa-trash-can"></i>
                                                                        Delete
                                                                    </button>
                                                                </td>
                                                            </tr>



                                                            <div class="modal fade" id="delete<?php echo e($loop->iteration); ?>"
                                                                tabindex="-1" aria-labelledby="exampleModalLabel"
                                                                aria-hidden="true">
                                                                <div class="modal-dialog">
                                                                    <div class="modal-content">
                                                                        <div class="modal-header bg-primary">
                                                                            <h1 class="modal-title fs-5 text-white"
                                                                                id="exampleModalLabel">
                                                                                Delete Bid
                                                                            </h1>
                                                                            <button type="button" class="btn-close"
                                                                                data-bs-dismiss="modal"
                                                                                aria-label="Close"></button>
                                                                        </div>
                                                                        <div class="modal-body">
                                                                            <div class="text-center">
                                                                                <p class="">
                                                                                    <i class="fa-solid fa-triangle-exclamation"
                                                                                        style="font-size: 25px;"></i>
                                                                                    <br>
                                                                                    Are you sure you want to delete this
                                                                                    Bid?
                                                                                </p>
                                                                            </div>
                                                                        </div>
                                                                        <div class="modal-footer">
                                                                            <button type="button" class="btn btn-secondary"
                                                                                data-bs-dismiss="modal">Close</button>
                                                                            <a href="<?php echo e(route('transporter.delete.mybids', ['id' => $item->id])); ?>"
                                                                                class="btn btn-danger">Yes, Delete</a>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>


                                                            
                                                            <div class="modal fade" id="info<?php echo e($loop->iteration); ?>"
                                                                tabindex="-1" aria-labelledby="exampleModalLabel"
                                                                aria-hidden="true">
                                                                <div class="modal-dialog">
                                                                    <div class="modal-content">
                                                                        <div class="modal-header bg-primary">
                                                                            <h1 class="modal-title fs-5 text-white"
                                                                                id="exampleModalLabel">
                                                                                Request Details
                                                                            </h1>
                                                                            <button type="button" class="btn-close"
                                                                                data-bs-dismiss="modal"
                                                                                aria-label="Close"></button>
                                                                        </div>
                                                                        <div class="modal-body">
                                                                            <div>
                                                                                <p><strong>Origin:</strong>
                                                                                    <?php echo e(ucfirst($item->requestTruck->origin) ?? 'N/A'); ?>

                                                                                </p>
                                                                                <p><strong>Destination:</strong>
                                                                                    <?php echo e(ucfirst($item->requestTruck->destination) ?? 'N/A'); ?>

                                                                                </p>
                                                                                <p><strong>Distance:</strong>
                                                                                    <?php echo e($item->requestTruck->distance ?? 'N/A'); ?>

                                                                                </p>
                                                                                <p><strong>Time:</strong>
                                                                                    <?php echo e($item->requestTruck->time ?? 'N/A'); ?>

                                                                                </p>
                                                                                <p><strong>Material:</strong>
                                                                                    <?php echo e($item->requestTruck->material ?? 'N/A'); ?>

                                                                                </p>
                                                                                <p><strong>Weight:</strong>
                                                                                    <?php echo e($item->requestTruck->weight ?? 'N/A'); ?>

                                                                                </p>
                                                                                <p><strong> Truck Type:</strong>
                                                                                    <?php echo e($item->requestTruck->type ?? 'N/A'); ?>

                                                                                </p>
                                                                                <p><strong> No. of Trucks:</strong>
                                                                                    <?php echo e($item->requestTruck->quantity ?? 'N/A'); ?>

                                                                                </p>
                                                                                <p><strong> Schedule Date:</strong>
                                                                                    <?php echo e(\Carbon\Carbon::parse($item->requestTruck->schedule_date)->format('d M Y') ?? 'N/A'); ?>

                                                                                </p>
                                                                                <p><strong> Source Pin Code:</strong>
                                                                                    <?php echo e($item->requestTruck->source_pin ?? 'N/A'); ?>

                                                                                </p>
                                                                                <p><strong> Destination Pin Code:</strong>
                                                                                    <?php echo e($item->requestTruck->destination_pin ?? 'N/A'); ?>

                                                                                </p>
                                                                                <p><strong> Pickup Type:</strong>
                                                                                    <?php echo e($item->requestTruck->pickup_type ?? 'N/A'); ?>

                                                                                </p>
                                                                                <p><strong> Pickup Date:</strong>
                                                                                    <?php echo e(\Carbon\Carbon::parse($item->requestTruck->pickup_date)->format('d M Y') ?? 'N/A'); ?>

                                                                                </p>
                                                                                <p><strong> Request Date:</strong>
                                                                                    <?php echo e($item->requestTruck->created_at->format('d M Y') ?? 'N/A'); ?>

                                                                                </p>
                                                                            </div>
                                                                        </div>
                                                                        <div class="modal-footer">
                                                                            <button type="button" class="btn btn-secondary"
                                                                                data-bs-dismiss="modal">Close</button>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </form>
                                    </div>
                                    <!-- /.card-body -->
                                </div>
                                <!-- /.card -->
                            </div>
                            <!-- /.col -->
                        </div>
                        <!-- /.row -->
                    </div>
                    <!-- /.container-fluid -->
                </section>
                <!-- /.content -->

            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('transporter.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\FixTech Solution\Truck-Management\resources\views\transporter\mybids.blade.php ENDPATH**/ ?>