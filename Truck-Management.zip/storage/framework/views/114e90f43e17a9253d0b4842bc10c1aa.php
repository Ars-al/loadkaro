    

    <?php $__env->startSection('section'); ?>

    <div class="page-wrapper">
        <div class="content container-fluid">
             <!-- Page Header -->
             <div class="page-header">
                <div class="d-flex align-items-center">
                    <div class="col">
                        <h3 class="page-title"><?php echo e($title ?? ''); ?></h3>
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item">
                                <a href="<?php echo e(route('index')); ?>">
                                    Dashboard
                                </a>
                            </li>
                            <li class="breadcrumb-item active"><?php echo e($title ?? ''); ?></li>
                        </ul>
                    </div>
                    <div class="d-flex justify-content-end gap-2">
                        <a href="<?php echo e(route('plans.create')); ?>" class="btn btn-primary">
                            <i class="fa-solid fa-circle-plus"></i>
                            Create Plan
                        </a>
                    </div>
                </div>
            </div>
            <!-- /Page Header -->


            <section class="content text-center mt-5">
                <div class="row  my-4">
                    <?php if($plans->count() > 0): ?>
                        <?php $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-4">
                                <div class="card plan-card mb-4 shadow-sm">
                                    <div class="card-header text-center py-3">
                                        <h4 class="plan-title mb-0"><?php echo e($plan->name); ?></h4>
                                    </div>
                                    <div class="card-body">
                                        <h2 class="plan-price mb-3"><?php echo e('₹' . $plan->price); ?></h2>
                                        <p>Leads Limit: <?php echo e($plan->leads_limit); ?></p>
                                        <a href="<?php echo e(route('plans.edit', $plan->id)); ?>" class="btn btn-primary mt-3">Edit Plan</a>
                                        
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <p>No plans available.</p>
                    <?php endif; ?>
                </div>
            </section>
        </div>
    </div>

    <style>
        .plan-card {
            border-radius: 10px;
            border: 2px solid #E0E0E0;
            background-color: #F7F7F7;
        }

        .plan-title {
            font-size: 24px;
            color: #fff;
            background-color: #7D009A;
            border-radius: 10px 10px 0 0;
            padding: 10px 0;
        }

        .plan-price {
            font-size: 36px;
            color: #333;
            font-weight: bold;
        }

        .plan-features {
            font-size: 16px;
            color: #666;
        }

        /* .btn-primary {
            background-color: #6C63FF;
            border-color: #6C63FF;
            border-radius: 50px;
            font-size: 16px;
        }

        .btn-primary:hover {
            background-color: #5249e5;
            border-color: #5249e5;
        } */

        h2 {
            font-size: 32px;
            color: #333;
            margin-bottom: 20px;
        }
    </style>

    <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\FixTech Solution\Truck-Management\resources\views\admin\plans\index.blade.php ENDPATH**/ ?>