

<?php $__env->startSection('section'); ?>
<section class="content">
<div class="page-wrapper">
    <div class="content container-fluid">

    <div class="container-fluid">
        <div class="row">
            <div class="col-12">

                <div class="card">
                    <div class="card-body">

                    <form method="POST" action="<?php echo e(route('update-contact',$contact->id)); ?>">
    <?php echo csrf_field(); ?>
    <div class="row">
        <div class="form-group col-6">
            <label for="name">Name</label>
            <input type="text" name="name" class="form-control" id="name" placeholder="Enter name" value="<?php echo e($contact->name); ?>">
            <?php if($errors->has('name')): ?>
                <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
            <?php endif; ?>
        </div>

        <div class="form-group col-6">
            <label for="title">Subject</label>
            <input type="text" name="subject" class="form-control" id="subject" placeholder="Enter subject" value="<?php echo e($contact->subject); ?>">
            <?php if($errors->has('subject')): ?>
                <span class="text-danger"><?php echo e($errors->first('subject')); ?></span>
            <?php endif; ?>
        </div>
    </div>

    <div class="row">
        

        <div class="form-group col-6">
            <label for="price">Email</label>
            <input type="email" name="email" class="form-control" id="email" placeholder="Enter email" value="<?php echo e($contact->email); ?>">
            <?php if($errors->has('email')): ?>
                <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
            <?php endif; ?>
        </div>
    

    <div class="form-group col-6">
        <label for="description">Message</label>
        <textarea class="form-control" name="message" id="message" placeholder="Enter message"><?php echo e($contact->message); ?></textarea>
        <?php if($errors->has('message')): ?>
            <span class="text-danger"><?php echo e($errors->first('message')); ?></span>
        <?php endif; ?>
    </div>
    </div>
    <button type="submit" class="btn btn-primary">Submit</button>
</form>


                    </div>
                    <!-- /.card-body -->
                </div>
                <!-- /.card -->
            </div>
            <!-- /.col -->
        </div>
        <!-- /.row -->
    </div>
    <!-- /.container-fluid -->
</section>
<!-- /.content -->
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\FixTech Solution\Truck-Management\resources\views\admin\edit-contact-management.blade.php ENDPATH**/ ?>