<?php $__env->startSection('section'); ?>
    <section class="content">
        <div class="page-wrapper">
            <div class="content container-fluid">

                <div class="page-header">
                    <div class="row">
                        <div class="col">
                            <h3 class="page-title"><?php echo e($title ?? ''); ?></h3>
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item">
                                    <a href="<?php echo e(route('transporter.index')); ?>">
                                        Dashboard
                                    </a>
                                </li>
                                <li class="breadcrumb-item active"><?php echo e($title ?? ''); ?></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <!-- /Page Header -->

                <!-- Main content -->
                <section class="content">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-12">
                                <div class="card">
                                    
                                    <div class="card-body">
                                        <form action="" method="post">
                                            <?php echo csrf_field(); ?>
                                            <div class="table-responsive">
                                                <table class="datatable table table-hover table-center mb-0">
                                                    <thead>
                                                        <tr>
                                                            <th>#</th>
                                                            <th>Customer</th>
                                                            <th>Customer Phone</th>
                                                            <th>Status</th>
                                                            <th>Date</th>
                                                            <th>Action</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php $__currentLoopData = $allocatedBid; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <tr>
                                                                <td><?php echo e($loop->iteration); ?></td>
                                                                <td class="d-flex align-items-center gap-2">
                                                                    
                                                                    <img class="rounded-circle"
                                                                        src="<?php echo e(optional($item->requestTruck->customer)->image ? asset('Customer/profile/image/' . $item->requestTruck->customer->image) : asset('assets/img/no-img.jpeg')); ?>"
                                                                        width="40" height="40" alt="Customer Image">

                                                                    <ul class="list-unstyled mt-3">
                                                                        <li><?php echo e(ucfirst($item->requestTruck->customer->name ?? '')); ?>

                                                                        </li>
                                                                        <li><?php echo e($item->requestTruck->customer->email ?? ''); ?>

                                                                        </li>
                                                                    </ul>
                                                                </td>
                                                                <td><?php echo e($item->requestTruck->customer->phone ?? ''); ?></td>
                                                                <td>
                                                                    <span
                                                                        class="badge <?php echo e($payment && $payment->payment_status == 'successful' ? 'badge-success' : 'badge-danger'); ?>">
                                                                        <?php echo e($payment && $payment->payment_status == 'successful' ? 'Paid' : 'Unpaid'); ?>

                                                                    </span>
                                                                </td>
                                                                <td><?php echo e($item->created_at->format('d M Y') ?? ''); ?></td>
                                                                <td>
                                                                    <?php if($payment && $payment->payment_status == 'successful'): ?>
                                                                        <a href="<?php echo e(route('transporter.invoice', ['id' => $payment->id])); ?>"
                                                                            class="btn btn-primary btn-sm">
                                                                            <i class="fa-solid fa-file-invoice-dollar"></i>
                                                                            Invoice
                                                                        </a>
                                                                    <?php endif; ?>
                                                                    <a href="<?php echo e(route('transporter.chat', ['id' => $item->requestTruck->id])); ?>"
                                                                        class="btn btn-warning btn-sm">
                                                                        <i class="fa-solid fa-comment"></i>
                                                                        Chat
                                                                    </a>
                                                                </td>
                                                            </tr>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </form>
                                    </div>
                                    <!-- /.card-body -->
                                </div>
                                <!-- /.card -->
                            </div>
                            <!-- /.col -->
                        </div>
                        <!-- /.row -->
                    </div>
                    <!-- /.container-fluid -->
                </section>
                <!-- /.content -->

            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('transporter.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\FixTech Solution\Truck-Management\resources\views\transporter\bid-detail.blade.php ENDPATH**/ ?>