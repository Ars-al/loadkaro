<!-- Sidebar -->

<?php
    // Retrieve the transporter using the session ID
    $transporter = \App\Models\Transporters::find(session('transporter_id'));
?>

<div class="sidebar" id="sidebar">
    <div class="sidebar-inner slimscroll">
        <div id="sidebar-menu" class="sidebar-menu">
            <ul>

                <li class="<?php echo e(Route::is(['transporter.index']) ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('transporter.index')); ?>">
                        <i class="fa-solid fa-gauge"></i>
                        <span>Dashboard</span>
                    </a>
                </li>
                <?php if($transporter && $transporter->verified): ?>
                    <li class="<?php echo e(Route::is(['transporter.hiring.request']) ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('transporter.hiring.request')); ?>">
                            <i class="fa-solid fa-envelope-open-text"></i>
                            <span>Hiring Requests</span>
                        </a>
                    </li>

                    <li class="<?php echo e(Route::is(['transporter.mybids'], ['transporter.mybid.detail']) ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('transporter.mybids')); ?>">
                            <i class="fa-solid fa-envelope-open-text"></i>
                            <span>My Bids</span>
                        </a>
                    </li>
                    <li class="<?php echo e(Route::is(['subscriptions']) ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('subscriptions')); ?>">
                            <i class="fa-solid fa-envelope-open-text"></i>
                            <span>Subscriptions</span>
                        </a>
                    </li>
                <?php endif; ?>

            </ul>
        </div>
    </div>
</div>
<!-- /Sidebar -->
<?php /**PATH D:\FixTech Solution\Truck-Management\resources\views\transporter\layouts\sidebar.blade.php ENDPATH**/ ?>