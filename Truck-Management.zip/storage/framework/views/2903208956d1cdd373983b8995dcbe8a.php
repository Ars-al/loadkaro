<!-- Sidebar -->
            <div class="sidebar" id="sidebar">
                <div class="sidebar-inner slimscroll">
					<div id="sidebar-menu" class="sidebar-menu">
						<ul>

							<li class="<?php echo e(Route::is(['index']) ? 'active':''); ?>">
								<a href="<?php echo e(route('index')); ?>">
                                    <i class="fa-solid fa-gauge"></i>
                                    <span>Dashboard</span>
                                </a>
							</li>
							
							<li class="<?php echo e(Route::is(['customers']) ? 'active':''); ?>">
								<a href="<?php echo e(route('customers')); ?>">
                                    <i class="fe fe-users"></i>
                                    <span>Customers</span>
                                </a>
							</li>
							<li class="<?php echo e(Route::is(['transporters']) ? 'active':''); ?>">
								<a href="<?php echo e(route('transporters')); ?>">
                                    <i class="fa-solid fa-truck-front"></i>
                                    <span>Transporters</span>
                                </a>
							</li>
							<li class="<?php echo e(Route::is(['plans.index'], ['plans.create']) ? 'active':''); ?>">
								<a href="<?php echo e(route('plans.index')); ?>">
                                    <i class="fa-solid fa-cubes"></i>
                                    <span>Plans</span>
                                </a>
							</li>
                            <li class="">
                                <a href="<?php echo e(route('admin.subscription.index')); ?>">
                                    <i class="fa-solid fa-clipboard-list"></i>
                                    <span>Subscription Management</span>
                                </a>
                            </li>
							<li class="<?php echo e(Route::is(['contact-management']) ? 'active':''); ?>">
								<a href="<?php echo e(route('contact-management')); ?>">
                                    <i class="fa-solid fa-envelope-open-text"></i>
                                    <span>Contact Management</span>
                                </a>
							</li>
                            <li class="<?php echo e(Route::is(['website-setting']) ? 'active':''); ?>">
                                <a href="<?php echo e(route('website-setting')); ?>">
                                    <i class="fa-solid fa-wrench"></i>
                                    <span>Website Settings</span>
                                </a>
                            </li>
							<li class="<?php echo e(Route::is(['faq']) ? 'active':''); ?>">
								<a href="<?php echo e(route('faq')); ?>">
                                    <i class="fa-regular fa-circle-question"></i>
                                    <span>FAQs</span>
                                </a>
							</li>
							<li class="submenu">
								<a href="#">
                                    <i class="fa-solid fa-table"></i>
                                    <span> CMS</span> <span class="menu-arrow"></span>
                                </a>
								<ul style="display: none;">
									<li><a href="<?php echo e(route('privacy.policy')); ?>">Privacy Policy</a></li>
									<li><a href="<?php echo e(route('terms.conditions')); ?>">Terms And Conditions</a></li>
								</ul>
							</li>
						</ul>
					</div>
                </div>
            </div>
			<!-- /Sidebar -->
<?php /**PATH D:\FixTech Solution\Truck-Management\resources\views\admin\layouts\sidebar.blade.php ENDPATH**/ ?>