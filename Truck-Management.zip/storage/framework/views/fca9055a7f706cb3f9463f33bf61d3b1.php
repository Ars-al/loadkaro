<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>

<?php if(session("success")): ?>
<script>
    $(document).ready(function() {
        toastr.options =
		{
			"closeButton" : true,
			"progressBar" : true,
			"positionClass": "toast-bottom-right",
			"timeOut": 10000
		}
      	toastr.success("<?php echo e(session('success')); ?>");
    });
</script>
<?php endif; ?>

<?php if(session("error")): ?>
<script>
    $(document).ready(function() {
        toastr.options =
		{
			"closeButton" : true,
			"progressBar" : true,
			"positionClass": "toast-bottom-right",
			"timeOut": 10000
		}
      	toastr.error("<?php echo e(session('error')); ?>");
    });
</script>
<?php endif; ?>

<?php if(session("errors")): ?>
<script>
    $(document).ready(function() {
    	<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		  toastr.options = {
		      "closeButton" : true,
		      "progressBar" : true,
		      "positionClass": "toast-bottom-right",
		      "timeOut": 10000
		  }
		  toastr.error("<?php echo e($error); ?>");
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    });
</script>
<?php endif; ?><?php /**PATH D:\FixTech Solution\Truck-Management\resources\views\admin\layouts\toastr.blade.php ENDPATH**/ ?>