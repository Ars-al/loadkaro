<?php $__env->startSection('section'); ?>
    <div class="page-wrapper">
        <div class="content container-fluid">

            <!-- Page Header -->
            <div class="page-header">
                <div class="row">
                    <div class="col">
                        <h3 class="page-title"><?php echo e($title ?? ''); ?></h3>
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item">
                                <a href="<?php echo e(route('index')); ?>">
                                    Dashboard
                                </a>
                            </li>
                            <li class="breadcrumb-item active"><?php echo e($title ?? ''); ?></li>
                        </ul>
                    </div>
                </div>
            </div>
            <!-- /Page Header -->

            <!-- Main content -->
            <section class="content">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-12">

                            <div class="card">
                                <div class="card-header">
                                    <div class="d-flex justify-content-end gap-2">
                                        <a href="<?php echo e(route('add.faq')); ?>" class="btn btn-primary">
                                            <i class="fa-solid fa-circle-plus"></i>
                                            Add FAQ
                                        </a>
                                    </div>
                                </div>
                                <div class="card-body">
                                    <form action="" method="post">
                                        <?php echo csrf_field(); ?>
                                        <div class="table-responsive">
                                            <table class="datatable table table-hover table-center mb-0">
                                                <thead>
                                                    <tr>
                                                        <th>#</th>
                                                        <th>Title</th>
                                                        <th>Description</th>
                                                        <th>Date</th>
                                                        <th>Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php $__currentLoopData = $faqs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr>
                                                            <td><?php echo e($loop->iteration); ?></td>
                                                            <td><?php echo e(Str::limit(ucfirst($item->title) ?? '', 30)); ?></td>
                                                            <td><?php echo e(Str::limit($item->description ?? '', 40)); ?></td>

                                                            <td><?php echo e($item->created_at->format('d M Y')); ?></td>
                                                            <td>
                                                                <button class="btn btn-dark text-white btn-sm" type="button" data-bs-toggle="modal" data-bs-target="#info<?php echo e($loop->iteration); ?>">
                                                                    <i class="fa-solid fa-circle-info"></i>
                                                                    Detail
                                                                </button>
                                                                <button class="btn btn-danger btn-sm" type="button"
                                                                    data-bs-toggle="modal"
                                                                    data-bs-target="#delete<?php echo e($loop->iteration); ?>">
                                                                    <i class="fa-regular fa-trash-can"></i>
                                                                    Delete
                                                                </button>
                                                                <a href="<?php echo e(route('check.faq', ["id" =>$item->id])); ?>" class="btn btn-primary btn-sm" type="button">
                                                                    <i class="fa-regular fa-edit"></i>
                                                                    Update
                                                                </a>
                                                            </td>
                                                        </tr>

                                                        <div class="modal fade" id="info<?php echo e($loop->iteration); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                            <div class="modal-dialog modal-lg">
                                                                <div class="modal-content">
                                                                    <div class="modal-header bg-primary">
                                                                        <h1 class="modal-title fs-5 text-white" id="exampleModalLabel">
                                                                            FAQ Details
                                                                        </h1>
                                                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                                    </div>
                                                                    <div class="modal-body">
                                                                        <ul class="list-unstyled">
                                                                            <li>
                                                                                Name:
                                                                                <b>
                                                                                    <?php echo e(ucfirst($item->title ?? '')); ?>

                                                                                </b>
                                                                            </li>
                                                                            <li>
                                                                                Email:
                                                                                <b>
                                                                                    <?php echo e(ucfirst($item->description ?? '')); ?>

                                                                                </b>
                                                                            </li>
                                                                            <li>
                                                                                Date:
                                                                                <b>
                                                                                    <?php echo e($item->created_at->format('d M Y') ?? ''); ?>

                                                                                </b>
                                                                            </li>
                                                                        </ul>
                                                                    </div>
                                                                    <div class="modal-footer">
                                                                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>

                                                        <div class="modal fade" id="delete<?php echo e($loop->iteration); ?>"
                                                            tabindex="-1" aria-labelledby="exampleModalLabel"
                                                            aria-hidden="true">
                                                            <div class="modal-dialog">
                                                                <div class="modal-content">
                                                                    <div class="modal-header bg-primary">
                                                                        <h1 class="modal-title fs-5 text-white"
                                                                            id="exampleModalLabel">
                                                                            Delete Lead
                                                                        </h1>
                                                                        <button type="button" class="btn-close"
                                                                            data-bs-dismiss="modal"
                                                                            aria-label="Close"></button>
                                                                    </div>
                                                                    <div class="modal-body">
                                                                        <div class="text-center">
                                                                            <p class="">
                                                                                <i class="fa-solid fa-triangle-exclamation"
                                                                                    style="font-size: 25px;"></i>
                                                                                <br>
                                                                                Are you sure you want to delete this lead?
                                                                            </p>
                                                                        </div>
                                                                    </div>
                                                                    <div class="modal-footer">
                                                                        <button type="button" class="btn btn-secondary"
                                                                            data-bs-dismiss="modal">Close</button>
                                                                        <a href="<?php echo e(route('delete.faq', ["id" => $item->id])); ?>" class="btn btn-danger">Yes,
                                                                            Delete</a>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </form>
                                </div>
                                <!-- /.card-body -->
                            </div>
                            <!-- /.card -->
                        </div>
                        <!-- /.col -->
                    </div>
                    <!-- /.row -->
                </div>
                <!-- /.container-fluid -->
            </section>
            <!-- /.content -->
        </div>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\FixTech Solution\Truck-Management\resources\views\admin\faqs.blade.php ENDPATH**/ ?>