<?php $__env->startSection('section'); ?>
    <section class="content">
        <div class="page-wrapper">
            <div class="content container-fluid">
                <div class="container mt-5">
                    <div class="row justify-content-center">
                        <div class="col-md-8">
                            <div class="card shadow-sm">
                                <div class="card-header bg-primary text-white">
                                    <h4 class="mb-0">Complete Payment for <?php echo e($plan->name); ?> Plan</h4>
                                </div>
                                <div class="card-body">

                                    <?php
                                        $userInfo = session('transporter_id')
                                            ? \App\Models\Transporters::find(session('transporter_id'))
                                            : null;
                                    ?>

                                    <?php if($userInfo): ?>
                                        <form action="<?php echo e(route('subscription.callback')); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <p class="mb-3">Click the button below to complete your payment securely:</p>
                                            <script src="https://checkout.razorpay.com/v1/checkout.js" data-key="rzp_test_VgsfHLzyQVgNL1"
                                                data-amount="<?php echo e($order['amount']); ?>" data-currency="INR" data-order_id="<?php echo e($order['id']); ?>"
                                                data-buttontext="Pay ₹<?php echo e($plan->price); ?>" data-name="LoadKaro" data-description="Subscription Payment"
                                                data-image="https://your-logo-url.com/logo.png" data-prefill.name="<?php echo e($userInfo->name); ?>"
                                                data-prefill.email="<?php echo e($userInfo->email); ?>" data-theme.color="#F37254"></script>
                                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                                        </form>
                                    <?php else: ?>
                                        <div class="alert alert-warning text-center">
                                            Transporter information not found. Please try again.
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('transporter.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\FixTech Solution\Truck-Management\resources\views\transporter\subscription\checkout.blade.php ENDPATH**/ ?>