<?php $__env->startSection('section'); ?>
    <section class="content">
        <div class="page-wrapper">
            <div class="content container-fluid">

                <div class="page-header">
                    <div class="row">
                        <div class="col">
                            <h3 class="page-title"><?php echo e($title ?? ''); ?></h3>
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item">
                                    <a href="<?php echo e(route('transporter.index')); ?>">
                                        Dashboard
                                    </a>
                                </li>
                                <li class="breadcrumb-item active"><?php echo e($title ?? ''); ?></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <!-- /Page Header -->

                <!-- Main content -->
                <section class="content">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-12">
                                <div class="card">
                                    <div class="card-body">
                                        <form action="" method="post">
                                            <?php echo csrf_field(); ?>
                                            <div class="table-responsive">
                                                <table class="datatable table table-hover table-center mb-0">
                                                    <thead>
                                                        <tr>
                                                            <th>#</th>
                                                            <th>Transporter</th>
                                                            <th>Transporter Phone</th>
                                                            <th>Bid</th>
                                                            <th>Status</th>
                                                            <th>Date</th>
                                                            <th>Action</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php $__currentLoopData = $truck; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <tr>
                                                                <td><?php echo e($loop->iteration); ?></td>
                                                                <td class="d-flex align-items-center gap-2">
                                                                    
                                                                    <img class="rounded-circle"
                                                                        src="<?php echo e($item->winingbid->transporter->image
                                                                            ? asset('Transporter/profile/image/' . $item->winingbid->transporter->image)
                                                                            : asset('assets/img/no-img.jpeg')); ?>"
                                                                        width="40" height="40"
                                                                        alt="Transporter Image">

                                                                    <ul class="list-unstyled mt-3">
                                                                        <li><?php echo e(ucfirst($item->winingbid->transporter->name ?? '')); ?>

                                                                        </li>
                                                                        <li><?php echo e($item->winingbid->transporter->email ?? ''); ?>

                                                                        </li>
                                                                    </ul>
                                                                </td>
                                                                <td><?php echo e($item->winingbid->transporter->phone ?? ''); ?></td>
                                                                <td>₹<?php echo e(number_format($item->winingbid->bid, 2) ?? ''); ?>

                                                                </td>
                                                                <td>
                                                                    <?php if($payment): ?>
                                                                        <?php if($payment->payment_status): ?>
                                                                            <span
                                                                                class="badge <?php echo e($payment->payment_status == 'successful' ? 'badge-success' : 'badge-danger'); ?>">
                                                                                <?php echo e($payment->payment_status == 'successful' ? 'Paid' : 'Unpaid'); ?>

                                                                            </span>
                                                                        <?php else: ?>
                                                                            <span class="badge badge-danger">Unpaid</span>
                                                                        <?php endif; ?>
                                                                    <?php else: ?>
                                                                        <span class="badge badge-danger">Unpaid</span>
                                                                    <?php endif; ?>

                                                                </td>
                                                                <td><?php echo e($item->winingbid->created_at->format('d M Y') ?? ''); ?>

                                                                </td>
                                                                <td>
                                                                    
                                                                    <?php if($customer->verified != false): ?>
                                                                        <?php if($payment && $payment->payment_status == 'successful'): ?>
                                                                            <a href="<?php echo e(route('customer.invoice', $payment->id)); ?>"
                                                                                class="btn btn-primary btn-sm">
                                                                                <i
                                                                                    class="fa-solid fa-file-invoice-dollar"></i>
                                                                                Invoice
                                                                            </a>
                                                                        <?php else: ?>
                                                                            <a href="<?php echo e(route('payment.initiate', [
                                                                                'request_truck_id' => $item->id,
                                                                                'transporter_id' => $item->winingbid->transporter->id,
                                                                                'amount' => $item->winingbid->bid,
                                                                            ])); ?>"
                                                                                class="btn btn-success btn-sm">
                                                                                <i class="fa-regular fa-money-bill-1"></i>
                                                                                Pay
                                                                            </a>
                                                                        <?php endif; ?>
                                                                    <?php else: ?>
                                                                        
                                                                        <a href="<?php echo e(route('customer.pan.verify.page', ['id' => $customer->id])); ?>"
                                                                            class="btn btn-primary btn-sm">
                                                                            <i class="fa-regular fa-circle-check"></i>
                                                                            Verify
                                                                        </a>
                                                                    <?php endif; ?>
                                                                    <a href="<?php echo e(route('customer.chat', ['id' => $item->id])); ?>"
                                                                        class="btn btn-warning btn-sm">
                                                                        <i class="fa-solid fa-comment"></i>
                                                                        Chat
                                                                    </a>
                                                                </td>
                                                            </tr>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </form>
                                    </div>
                                    <!-- /.card-body -->
                                </div>
                                <!-- /.card -->
                            </div>
                            <!-- /.col -->
                        </div>
                        <!-- /.row -->
                    </div>
                    <!-- /.container-fluid -->
                </section>
                <!-- /.content -->

            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('customer.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\FixTech Solution\Truck-Management\resources\views\customer\request-detail.blade.php ENDPATH**/ ?>