<?php $__env->startSection('section'); ?>

    <section class="content">
        <div class="page-wrapper">
            <div class="content container-fluid">

                <!-- Page Header -->
                <div class="page-header">
                    <div class="row">
                        <div class="col">
                            <h3 class="page-title"><?php echo e($title ?? ''); ?></h3>
                            <ul class="breadcrumb">
                                <li class="breadcrumb-item">
                                    <a href="<?php echo e(route('customer.index')); ?>">
                                        Dashboard
                                    </a>
                                </li>
                                <li class="breadcrumb-item active"><?php echo e($title ?? ''); ?></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <!-- /Page Header -->


                <div class="container-fluid">
                    <div class="row">
                        <div class="col-12">
                            <form method="POST" action="<?php echo e(route('customer.update.truck', ["id" => $truck->id])); ?>">
                                <?php echo csrf_field(); ?>
                                <div class="card">
                                    <div class="card-body">

                                        <div class="row">
                                            <div class="form-group col-6">
                                                <label for="name">Truck Type</label>
                                                <input type="text" name="type" class="form-control" id=""
                                                    placeholder="Enter Type" value="<?php echo e($truck->type ?? ''); ?>" required>
                                            </div>

                                            <div class="form-group col-6">
                                                <label for="title">Weight</label>
                                                <input type="text" name="weight" class="form-control"
                                                    placeholder="Enter Weight" value="<?php echo e($truck->weight ?? ''); ?>" required>
                                            </div>
                                        </div>

                                        <div class="row">
                                            <div class="form-group col-6">
                                                <label for="price">Qauntity</label>
                                                <input type="text" name="quantity" class="form-control"
                                                    placeholder="Enter Qauntity" value="<?php echo e($truck->quantity ?? ''); ?>" required>
                                            </div>

                                            <div class="form-group col-6">
                                                <label for="price">Origin</label>
                                                <input type="text" name="origin" class="form-control"
                                                    placeholder="Enter Origin" value="<?php echo e($truck->origin ?? ''); ?>" required>
                                            </div>
                                        </div>

                                        <div class="row">
                                            <div class="form-group col-6">
                                                <label for="price">Destination</label>
                                                <input type="text" name="destination" class="form-control"
                                                    placeholder="Enter Destination" value="<?php echo e($truck->destination ?? ''); ?>" required>
                                            </div>

                                        </div>

                                        <button type="submit" class="btn btn-primary">Update</button>
                                    </div>
                                </div>
                                <!-- /.card -->
                            </form>
                        </div>
                        <!-- /.col -->
                    </div>
                    <!-- /.row -->
                </div>
                <!-- /.container-fluid -->
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('customer.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\FixTech Solution\Truck-Management\resources\views\customer\update-truck-request.blade.php ENDPATH**/ ?>