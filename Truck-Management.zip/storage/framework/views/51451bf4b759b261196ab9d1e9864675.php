<p>Your Email verification code is: <?php echo e($emailOtp); ?></p>
<?php /**PATH D:\FixTech Solution\Truck-Management\resources\views\transporter\emails\otp.blade.php ENDPATH**/ ?>