<?php $__env->startSection('section'); ?>
    <!-- Page Wrapper -->

    <div class="page-wrapper">
        <div class="content container-fluid">

            <!-- Page Header -->
            <div class="page-header">
                <div class="row">
                    <div class="col">
                        <h3 class="page-title">Profile</h3>
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item"><a href="index.html">Dashboard</a></li>
                            <li class="breadcrumb-item active">Profile</li>
                        </ul>
                    </div>
                </div>
            </div>
            <!-- /Page Header -->

            <div class="row">
                <div class="col-md-12">
                    <div class="card">
                        <div class="card-body">
                             <div></div>
                            <div class="row">
                                <div class="">
                                    <form action="<?php echo e(route('customer.updateprofile')); ?>" method="POST" enctype="multipart/form-data">
                                        <?php echo csrf_field(); ?>
                                        <div class="row">
                                            <div class="mb-3 col-6">
                                                <label class="mb-2">Name</label>
                                                <input type="text" name="name" value="<?php echo e($customer->name ?? 'N/A'); ?>" class="form-control">
                                            </div>
                                            <div class="mb-3 col-6">
                                                <label class="mb-2">Email</label>
                                                <input type="email" name="email" value="<?php echo e($customer->email ?? 'N/A'); ?>" class="form-control" disabled>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="mb-3 col-6">
                                                <label class="mb-2">Phone Number</label>
                                                <input type="text" name="phone" value="<?php echo e($customer->phone ?? 'N/A'); ?>" class="form-control">
                                            </div>
                                            <div class="mb-3 col-6">
                                                <label class="mb-2">Image</label>
                                                <input type="file" name="image" class="form-control">
                                            </div>
                                        </div>

                                        <div class="row">
                                            <div class="mb-3 col-6">
                                                <label class="mb-2">Verified Aadhaar Number</label>
                                                <input type="text" name="verified_aadhaar" value="<?php echo e($customer->aadhaar_number ?? 'N/A'); ?>"
                                                    class="form-control" disabled>
                                            </div>
                                            <div class="mb-3 col-6">
                                                <label class="mb-2">Verified Pan Number</label>
                                                <input type="text" name="verified_pan" class="form-control" value="<?php echo e($customer->pan_number ?? 'N/A'); ?>" disabled>
                                            </div>
                                        </div>

                                        <div class="row">
                                            <div class="mb-3 col-6">
                                                <label class="mb-2">New Password (Optional)</label>
                                                <input type="password" name="password" autocomplete="off" class="form-control">
                                            </div>
                                            <div class="mb-3 col-6">
                                                <label class="mb-2">Confirm Password</label>
                                                <input type="password" name="password_confirmation" autocomplete="off" class="form-control">
                                            </div>

                                        </div>
                                        <button class="btn btn-primary" type="submit">Update</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>

            </div>
        </div>

        <!-- /Page Wrapper -->
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('customer.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\FixTech Solution\Truck-Management\resources\views\customer\profile.blade.php ENDPATH**/ ?>