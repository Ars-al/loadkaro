<?php $__env->startSection('section'); ?>
    <section class="content">
        <div class="page-wrapper">
            <div class="content container-fluid">
                <div class="container mt-5">
                    <div class="row justify-content-center">
                        <div class="col-md-8">
                            <div class="card shadow-sm">
                                <div class="card-header bg-primary text-white">
                                    <h4 class="mb-0">Complete Payment</h4>
                                </div>
                                <div class="card-body">
                                    <?php if(session('customer_id')): ?>
                                        <?php
                                            $userInfo = \App\Models\Customers::find(session('customer_id'));
                                        ?>
                                        <form action="<?php echo e(route('payment.callback')); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <p class="mb-3">Click the button below to complete your payment securely:</p>
                                            <script src="https://checkout.razorpay.com/v1/checkout.js" data-key="rzp_test_VgsfHLzyQVgNL1"
                                                data-amount="<?php echo e($order['amount']); ?>" data-currency="INR" data-order_id="<?php echo e($order['id']); ?>"
                                                data-buttontext="Pay with Razorpay" data-name="LoadKaro"
                                                data-description="Payment for order #<?php echo e($order['receipt']); ?>" data-image="<?php echo e(asset('assets/img/logo.png')); ?>"
                                                data-prefill.name="<?php echo e($userInfo->name); ?>" data-prefill.email="<?php echo e($userInfo->email); ?>" data-theme.color="#F37254">
                                            </script>
                                            <input type="hidden" custom="Hidden Element" name="hidden">
                                        </form>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>





<?php echo $__env->make('customer.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\FixTech Solution\Truck-Management\resources\views\customer\checkout.blade.php ENDPATH**/ ?>