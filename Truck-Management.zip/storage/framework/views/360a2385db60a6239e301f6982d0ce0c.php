</div>
<!-- /Main Wrapper -->

<!-- Bootstrap Core JS -->
<script src="<?php echo e(asset('assets/js/bootstrap.bundle.min.js')); ?>"></script>

<!-- Slimscroll JS -->
<script src="<?php echo e(asset('assets/plugins/slimscroll/jquery.slimscroll.min.js')); ?>"></script>

<script src="<?php echo e(asset('assets/plugins/raphael/raphael.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/plugins/morris/morris.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/chart.morris.js')); ?>"></script>


<script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-bs4.min.js"></script>

<!-- Custom JS -->
<script src="<?php echo e(asset('assets/js/script.js')); ?>"></script>


</body>
</html>

<script>
    $(document).ready(function() {
        $('.numericInput').on('input', function() {
            this.value = this.value.replace(/[^0-9]/g, '');
        });
    });
</script>
<?php /**PATH D:\FixTech Solution\Truck-Management\resources\views/customer/layouts/footer.blade.php ENDPATH**/ ?>