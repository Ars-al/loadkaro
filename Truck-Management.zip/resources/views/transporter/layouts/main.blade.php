@include('transporter.layouts.header')

@include('transporter.layouts.sidebar')

@yield('section')

@include('transporter.layouts.footer')

@include('transporter.layouts.toastr')
