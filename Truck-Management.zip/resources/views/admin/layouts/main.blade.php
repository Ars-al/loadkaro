@include('admin.layouts.header')

@include('admin.layouts.sidebar')

@yield('section')

@include('admin.layouts.footer')

@include('admin.layouts.toastr')