@include('customer.layouts.header')

@include('customer.layouts.sidebar')

@yield('section')

@include('customer.layouts.footer')

@include('customer.layouts.toastr')
