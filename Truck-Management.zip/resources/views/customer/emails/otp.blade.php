<p>Your Email verification code is: {{ $emailOtp }}</p>
